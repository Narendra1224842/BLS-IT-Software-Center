# BLS IT Software Center

Bilingual Hindi/English starter website for GitHub Pages.

## Publish on GitHub Pages
1. Open your repository: `Narendra1224842/BLS-IT-Software-Center`.
2. Click **Add file → Upload files**.
3. Upload `index.html` from this folder (and optionally `README.md`).
4. Click **Commit changes**.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main`, folder `/(root)`, then click **Save**.
8. Wait a few minutes and refresh the Pages section for the published URL.

## Important
- Replace the example `https://example.com` entries with official, verified download URLs.
- Do not distribute software/drivers unless you have permission and the source is trusted.
- The included Admin Panel is a demo using browser localStorage. It is not a secure login and changes are visible only in that browser. For a real public admin panel shared across visitors, add a backend database (e.g. Firebase/Supabase) with authentication and database security rules.
